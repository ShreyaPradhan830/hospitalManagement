package org.anudip.hospitalManagement.exception;

public class NoSuchElementException extends RuntimeException {
	private static final long serialVersionUID = 4L;
	

}
