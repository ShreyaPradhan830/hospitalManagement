package org.anudip.hospitalManagement.exception;

public class PayStatusException extends RuntimeException {
	private static final long serialVersionUID = 2L;
	

}
